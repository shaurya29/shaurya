#----------------------Bayes_A/B Testing----------------------#

setwd("~/ABtesting (copy)")
exp.data = read.csv(file = "exp1.csv", stringsAsFactors = FALSE)
exp.data = data.frame(exp.data)
str(exp.data)

exp.data$control_target = as.factor(exp.data$control_target)
exp.data[,1] = NULL
summary(exp.data)
df_BM <- data.frame("Names" = character(0),"P_Value1" = integer(0),"P_Values2" = integer(0),"P_Values3" = integer(0),"P_Value4" = integer(0),"P_Values5" = integer(0),"P_Values6" = integer(0),"Mean_of_grp_A" = integer(0),"Mean_of_grp_B" = integer(0),"Mean_of_grp_C" = integer(0),"Mean_of_grp_D" = integer(0),stringsAsFactors = FALSE)

#------------------For_loop---------------------------------------#
#shape(alpha) values represent the total event counts in each group
#scale(beta) values represent the exposure, that is, the relative opportunity for events to occur.
for(i in 2:(ncol(exp.data))){
  exp.name = names(exp.data)[i]
  exp.class = class(exp.data[,i])
  print(exp.name)
  if (exp.class %in% c('integer', 'numeric')){
    shape1 = ((mean(exp.data[exp.data$control_target == 'control',i]))^2/var(exp.data[exp.data$control_target == 'control',i]))
    scale1 = (var(exp.data[exp.data$control_target == 'control',i])/mean(exp.data[exp.data$control_target == 'control',i]))
    shape2 = ((mean(exp.data[exp.data$control_target == 'Hidden',i]))^2/var(exp.data[exp.data$control_target == 'Hidden',i]))
    scale2 = (var(exp.data[exp.data$control_target == 'Hidden',i])/mean(exp.data[exp.data$control_target == 'Hidden',i]))
    shape3 = ((mean(exp.data[exp.data$control_target == 'hide leaderboards',i]))^2/var(exp.data[exp.data$control_target == 'hide leaderboards',i]))
    scale3 = (var(exp.data[exp.data$control_target == 'hide leaderboards',i])/mean(exp.data[exp.data$control_target == 'hide leaderboards',i]))
    shape4 = ((mean(exp.data[exp.data$control_target == 'original',i]))^2/var(exp.data[exp.data$control_target == 'original',i]))
    scale4 = (var(exp.data[exp.data$control_target == 'original',i])/mean(exp.data[exp.data$control_target == 'original',i]))
    n.trials = 100000
    a.samples <- rgamma(n.trials,shape = shape2,scale = scale2)
    b.samples <- rgamma(n.trials,shape = shape1, scale = scale1)
    c.samples <- rgamma(n.trials,shape = shape4,scale = scale4)
    d.samples <- rgamma(n.trials,shape = shape3, scale = scale3)
    p.b_superior <- sum(b.samples > a.samples)/n.trials
    p.b_superior1 <- sum(c.samples > a.samples)/n.trials
    p.b_superior2 <- sum(d.samples > a.samples)/n.trials
    p.b_superior3 <- sum(c.samples > b.samples)/n.trials
    p.b_superior4 <- sum(d.samples > b.samples)/n.trials
    p.b_superior5 <- sum(d.samples > c.samples)/n.trials
    p.b_superior[is.na(p.b_superior)] <- 0
    p.b_superior1[is.na(p.b_superior1)] <- 0
    p.b_superior2[is.na(p.b_superior2)] <- 0
    p.b_superior3[is.na(p.b_superior3)] <- 0
    p.b_superior4[is.na(p.b_superior4)] <- 0
    p.b_superior5[is.na(p.b_superior5)] <- 0
    1-p.b_superior
    1-p.b_superior1
    1-p.b_superior2
    1-p.b_superior3
    1-p.b_superior4
    1-p.b_superior5
    Mean_A = mean(exp.data[exp.data$control_target == 'control',i])
    Mean_B = mean(exp.data[exp.data$control_target == 'Hidden',i])
    Mean_C = mean(exp.data[exp.data$control_target == 'hide leaderboards',i])
    Mean_D = mean(exp.data[exp.data$control_target == 'original',i])
    Mean_A[is.na(Mean_A)] <- 0
    Mean_B[is.na(Mean_B)] <- 0
    Mean_C[is.na(Mean_C)] <- 0
    Mean_D[is.na(Mean_D)] <- 0
    df_BM[nrow(df_BM)+1,] <- c(exp.name,p.b_superior,p.b_superior1,p.b_superior2,p.b_superior3,p.b_superior4,p.b_superior5,Mean_A,Mean_B,Mean_C,Mean_D)
  }
}

#----------------------------
write.csv(df_BM,"df_BM.csv")

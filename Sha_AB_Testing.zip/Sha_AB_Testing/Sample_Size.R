c cx               setwd("~/ABtesting (copy)")
exp.data = read.csv(file = "exp1.csv", stringsAsFactors = FALSE)
exp.data = data.frame(exp.data)
str(exp.data)

options("scipen"=100, "digits"=4)
sample_size = data.frame(lift = numeric(0), sampleR= numeric(0), sampleA= numeric(0), sampleC1 = numeric(0), sampleC2 = numeric(0))

Base_conv = 0.02
Lower_conv = 0.01
Upper_conv = 0.04

i = 1
j = 0.01
while (i <= 20018) {
  if (exp.data %in% subset(exp.data, control_target %in% c('Hidden', 'original'))){
  sample_size[i,1] = j*100
  sample_size[i,2] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.8, alternative='two.sided', sig.level=0.05)$n
  sample_size[i,3] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.9, alternative='two.sided', sig.level=0.05)$n
  i = i + 1
  j = j + 0.01
  }else{
    sample_size[i,1] = j*100
    sample_size[i,2] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.8, alternative='two.sided', sig.level=0.05)$n
    sample_size[i,3] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.9, alternative='two.sided', sig.level=0.05)$n
    sample_size[i,4] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.7, alternative='two.sided', sig.level=0.05)$n
    sample_size[i,5] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.6, alternative='two.sided', sig.level=0.05)$n
    i = i + 1
  j = j + 0.01
}
}
sample_size

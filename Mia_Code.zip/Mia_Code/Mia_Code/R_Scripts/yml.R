library(yaml)

yml.params <- yaml.load_file('MappingBuffer.yml')
yml.args <- commandArgs(trailingOnly = TRUE)

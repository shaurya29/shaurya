
#----------------------Bayes_A/B Testing----------------------#

setwd("~/ABtesting (copy)")
exp.data = read.csv(file = "exp2.csv", stringsAsFactors = FALSE)
exp.data = data.frame(exp.data)
str(exp.data)
exp.data = subset(exp.data, control_target %in% c('enable', 'original'))

exp.data$control_target = as.factor(exp.data$control_target)
exp.data[,1] = NULL
summary(exp.data)
df_B1 <- data.frame("Names" = character(0),"P_Values" = integer(0),"Mean_of_grp_A" = integer(0),"Mean_of_grp_B" = integer(0),stringsAsFactors = FALSE)

#------------------For_loop---------------------------------------#

for(i in 2:(ncol(exp.data))){
  exp.name = names(exp.data)[i]
  exp.class = class(exp.data[,i])
  print(exp.name)
  if (exp.class %in% c('integer', 'numeric')){
    shape1 = ((mean(exp.data[exp.data$control_target == 'enable',i]))^2/var(exp.data[exp.data$control_target == 'enable',i]))
    scale1 = (var(exp.data[exp.data$control_target == 'enable',i])/mean(exp.data[exp.data$control_target == 'enable',i]))
    shape2 = ((mean(exp.data[exp.data$control_target == 'original',i]))^2/var(exp.data[exp.data$control_target == 'original',i]))
    scale2 = (var(exp.data[exp.data$control_target == 'original',i])/mean(exp.data[exp.data$control_target == 'original',i]))
    n.trials = 100000
    a.samples <- rgamma(n.trials,shape = shape2,scale = scale2)
    b.samples <- rgamma(n.trials,shape = shape1, scale = scale1)
    p.b_superior <- sum(b.samples > a.samples)/n.trials
    p.b_superior[is.na(p.b_superior)] <- 0
    1-p.b_superior
    Mean_A = mean(exp.data[exp.data$control_target == 'enable',i])
    Mean_B = mean(exp.data[exp.data$control_target == 'original',i])
    Mean_A[is.na(Mean_A)] <- 0
    Mean_B[is.na(Mean_B)] <- 0
    df_B1[nrow(df_B1)+1,] <- c(exp.name,p.b_superior,Mean_A,Mean_B)
  }
}

#-------------Calculating % diff between mean--------------------

df_B1$Mean_of_grp_A = as.numeric(df_B1$Mean_of_grp_A)
df_B1$Mean_of_grp_B = as.numeric(df_B1$Mean_of_grp_B)
mean_table <- cbind(df_B1$Mean_of_grp_A,df_B1$Mean_of_grp_B)
colnames(mean_table) <- c("Mean_of_grp_A","Mean_of_grp_B")
mean_table[is.na(mean_table)] <- 0
mean_table <- as.data.frame(mean_table)
Perc_diff_Means <- abs(mean_table$Mean_of_grp_A - mean_table$Mean_of_grp_B)*100
mean_table <- cbind(mean_table,Perc_diff_Means)
df_B1 <- cbind(df_B1,Perc_diff_Means)

#-----------saving both grpA and grpB in one data_frame--------------------------
write.csv(df_B1,"df_B1.csv")

#-------------------------------------------------------------------




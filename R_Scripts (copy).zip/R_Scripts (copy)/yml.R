print ("yml.R")

yml.params <- yaml.load_file('~/tuple_client/R_Scripts/MappingBuffer.yml')
yml.args <- commandArgs(trailingOnly = TRUE)

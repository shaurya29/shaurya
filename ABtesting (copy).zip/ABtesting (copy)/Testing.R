
##############################  Sample Size Calculator  #########################

options("scipen"=100, "digits"=4)
sample_size = data.frame(lift = numeric(0), sampleR= numeric(0), sampleA= numeric(0), sampleC1 = numeric(0), sampleC2 = numeric(0), sampleC3 = numeric(0))

Base_conv = 0.02
Lower_conv = 0.01
Upper_conv = 0.04

i = 1
j = 0.01
while (i <= 50) {
  sample_size[i,1] = j*100
  sample_size[i,2] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.8, alternative='two.sided', sig.level=0.05)$n
  sample_size[i,3] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.9, alternative='two.sided', sig.level=0.05)$n
  sample_size[i,4] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.7, alternative='two.sided', sig.level=0.05)$n
  sample_size[i,5] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.6, alternative='two.sided', sig.level=0.05)$n
  sample_size[i,6] = power.prop.test(p1=Base_conv, p2=(Base_conv*(1+j)), power=0.5, alternative='two.sided', sig.level=0.05)$n
  i = i + 1
  j = j + 0.01
}

sample_size

##############################  Bayesian Tests  #################################

quantile1 <- list(p=0.5, x=0.02)    
quantile2 <- list(p=0.99999,x=0.04) 
quantile3 <- list(p=0.00001,x=0.01)

findBeta <- function(quantile1,quantile2,quantile3)
{
  # find the quantiles specified by quantile1 and quantile2 and quantile3
  quantile1_p <- quantile1[[1]]; quantile1_q <- quantile1[[2]]
  quantile2_p <- quantile2[[1]]; quantile2_q <- quantile2[[2]]
  quantile3_p <- quantile3[[1]]; quantile3_q <- quantile3[[2]]
  
  # find the beta prior using quantile1 and quantile2
  priorA <- beta.select(quantile1,quantile2)
  priorA_a <- priorA[1]; priorA_b <- priorA[2]
  
  # find the beta prior using quantile1 and quantile3
  priorB <- beta.select(quantile1,quantile3)
  priorB_a <- priorB[1]; priorB_b <- priorB[2]
  
  # find the best possible beta prior
  diff_a <- abs(priorA_a - priorB_a); diff_b <- abs(priorB_b - priorB_b)
  step_a <- diff_a / 100; step_b <- diff_b / 100
  if (priorA_a < priorB_a) { start_a <- priorA_a; end_a <- priorB_a }
  else                     { start_a <- priorB_a; end_a <- priorA_a }
  if (priorA_b < priorB_b) { start_b <- priorA_b; end_b <- priorB_b }
  else                     { start_b <- priorB_b; end_b <- priorA_b }
  steps_a <- seq(from=start_a, to=end_a, length.out=1000)
  steps_b <- seq(from=start_b, to=end_b, length.out=1000)
  max_error <- 10000000000000000000
  best_a <- 0; best_b <- 0
  for (a in steps_a)
  {
    for (b in steps_b)
    {
      # priorC is beta(a,b)
      # find the quantile1_q, quantile2_q, quantile3_q quantiles of priorC:
      priorC_q1 <- qbeta(c(quantile1_p), a, b)
      priorC_q2 <- qbeta(c(quantile2_p), a, b)
      priorC_q3 <- qbeta(c(quantile3_p), a, b)
      priorC_error <- abs(priorC_q1-quantile1_q) +
        abs(priorC_q2-quantile2_q) +
        abs(priorC_q3-quantile3_q)
      if (priorC_error < max_error)
      {
        max_error <- priorC_error; best_a <- a; best_b <- b
      }
    }
  }
  print(paste("The best beta prior has a=",best_a,"b=",best_b))
}

library(LearnBayes)
findBeta(quantile1,quantile2,quantile3)

head(fl1.copy)

rm(fl1.conv)

fl1.conv = aggregate(fl1.copy$conversion_tag, by = list(fl1.copy$control_target), sum)
fl1.conv$total = aggregate(fl1.copy$conversion_tag, by = list(fl1.copy$control_target), length)[,2]

head(fl1.conv)

names(fl1.conv) = c('control_target', 'converted', 'total')

n.trials <- 100000
prior.alpha <- 38
prior.beta <- 1711
a.samples <- rbeta(n.trials,1218+prior.alpha,(15669 - 1218)+prior.beta)
b.samples <- rbeta(n.trials,1225+prior.alpha,(15736 - 1225)+prior.beta)
p.b_superior <- sum(b.samples > a.samples)/n.trials

1- p.b_superior

par(mfrow = c(1,1))
hist(b.samples/a.samples)

?rgamma

fl1.conv

mean(fl1.copy[[13]])
var(fl1.copy[[13]])
shape1 = ((mean(fl1.copy[fl1.copy$control_target == 'enable',13]))^2/var(fl1.copy[fl1.copy$control_target == 'enable',13]))
scale1 = (var(fl1.copy[fl1.copy$control_target == 'enable',13])/mean(fl1.copy[fl1.copy$control_target == 'enable',13]))
scale1
shape1

shape2 = ((mean(fl1.copy[fl1.copy$control_target == 'original',13]))^2/var(fl1.copy[fl1.copy$control_target == 'original',13]))
scale2 = (var(fl1.copy[fl1.copy$control_target == 'original',13])/mean(fl1.copy[fl1.copy$control_target == 'original',13]))
scale2
shape2


a.samplesx <- rgamma(n.trials,shape = shape2,scale = scale2)
b.samplesx <- rgamma(n.trials,shape = shape1, scale = scale1)
p.b_superiorx <- sum(b.samplesx > a.samplesx)/n.trials

1- p.b_superiorx

hist(b.samplesx/a.samplesx)

par(mfrow = c(1,2))
plot(density(a.samplesx))
plot(density(fl1.copy[fl1.copy$control_target == 'enable',13]))


################################  Frequentist Testing  ####################################

chisq.test(table(fl1.copy$control_target, fl1.copy$conversion_tag))$p.value

wilcox.test(fl1.copy[[13]] ~ fl1.copy$control_target)$p.value

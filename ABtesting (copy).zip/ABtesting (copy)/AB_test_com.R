#Group_A
#----------------------A/B Testing----------------------#
setwd("~/ABtesting (copy)")
exp.data = read.csv(file = "exp1.csv", stringsAsFactors = FALSE)
exp.data = data.frame(exp.data)
str(exp.data)
exp.data = subset(exp.data, control_target %in% c('Hidden', 'original'))

exp.data$control_target = as.factor(exp.data$control_target)
exp.data[,1] = NULL
summary(exp.data)
target = exp.data$control_target
exp.data = exp.data[,-3]
df <- data.frame("Names" = character(0),"P_Values_grpA" = integer(0),"Mean_of_grpA" = integer(0),stringsAsFactors = FALSE)

##---------------For_Loop--------------------##

for (i in 2:(ncol(exp.data))){
  exp.name = names(exp.data[i])
  exp.class = class(exp.data[,i])
  print(exp.name)
  if (exp.class %in% c('integer', 'numeric')){
    a = wilcox.test(exp.data[,i] ~ target)$p.value
    Mean = mean(exp.data[,i])
    Mean[is.na(Mean)] <- 0
    df[nrow(df)+1,] <- c(exp.name,a,Mean)
  }else {
    b = chisq.test(target,exp.data[,i])$p.value
    Mean = mean(exp.data[,i])
    Mean[is.na(Mean)] <- 0
    df[nrow(df)+1,]<- c(exp.name,b,Mean)
  }
}

#-------------------------------------------------------------------

##Group B
#----------------------A/B Testing----------------------#
setwd("~/ABtesting (copy)")
exp.data1 = read.csv(file = "exp2.csv", stringsAsFactors = FALSE)
exp.data1 = data.frame(exp.data1)
str(exp.data1)
exp.data1 = subset(exp.data1, control_target %in% c('enable', 'original'))

exp.data1$control_target = as.factor(exp.data1$control_target)
exp.data1[,1] = NULL
summary(exp.data1)
target = exp.data1$control_target
exp.data1 = exp.data1[,-3]
df1 <- data.frame("Names" = character(0),"P_Values_grpB" = integer(0),"Mean_of_grpB" = integer(0),stringsAsFactors = FALSE)

##---------------For_Loop--------------------##

for(i in 2:(ncol(exp.data1))){
  exp.name = names(exp.data1)[i]
  exp.class = class(exp.data1[,i])
  print(exp.name)
  if (exp.class %in% c('integer', 'numeric')){
    a = wilcox.test(exp.data1[,i] ~ target)$p.value
    Mean1 = mean(exp.data1[,i])
    Mean1[is.na(Mean1)] <- 0
    df1[nrow(df1)+1,] <- c(exp.name,a,Mean1)
  }else {
    b = chisq.test(target,exp.data1[,i])$p.value
    Mean1 = mean(exp.data1[,i])
    Mean1[is.na(Mean1)] <- 0
    df1[nrow(df1)+1,] <- c(exp.name,b,Mean1)
  }
}

#----------------------------------------------------------------

#-------------Calculating % diff between mean--------------------

df$Mean_of_grpA = as.numeric(df$Mean_of_grpA)
df1$Mean_of_grpB = as.numeric(df1$Mean_of_grpB)
mean_table <- cbind(df$Mean_of_grpA,df1$Mean_of_grpB)
colnames(mean_table) <- c("Mean_of_grpA","Mean_of_grpB")
mean_table[is.na(mean_table)] <- 0
mean_table <- as.data.frame(mean_table)
Perc_diff_Means <- abs(mean_table$Mean_of_grpA - mean_table$Mean_of_grpB)*100
mean_table <- cbind(mean_table,Perc_diff_Means)
df <- cbind(df,Perc_diff_Means)
df1 <- cbind(df1,Perc_diff_Means)

#-----------saving both grpA and grpB in one data_frame--------------------------

df <- df[,-4]
df1 <- df1[,-1]
df_final = cbind(df,df1)
df_final = df_final[c("Names","P_Values_grpA","P_Values_grpB","Mean_of_grpA","Mean_of_grpB","Perc_diff_Means")]
write.csv(df_final,"df_final.csv")
#------------------------------------------------------------------------

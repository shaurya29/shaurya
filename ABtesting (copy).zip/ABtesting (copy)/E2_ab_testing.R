#----------------------A/B Testing----------------------#
setwd("~/ABtesting (copy)")
exp.data1 = read.csv(file = "exp2.csv", stringsAsFactors = FALSE)
exp.data1 = data.frame(exp.data1)
str(exp.data1)
exp.data1 = subset(exp.data1, control_target %in% c('enable', 'original'))

exp.data1$control_target = as.factor(exp.data1$control_target)
exp.data1[,1] = NULL
summary(exp.data1)
target = exp.data1$control_target
exp.data1 = exp.data1[,-3]
df1 <- data.frame("Names" = character(0),"P_Values" = integer(0),stringsAsFactors = FALSE)

##---------------For_Loop--------------------##

for(i in 1:(ncol(exp.data1))){
  exp.name = names(exp.data1)[i]
  exp.class = class(exp.data1[,i])
  print(exp.name)
  if (exp.class %in% c('integer', 'numeric')){
    a = wilcox.test(exp.data1[,i] ~ target)$p.value
    df1[nrow(df1)+1,] <- c(exp.name,a)
  }else {
    b = chisq.test(target,exp.data1[,i])$p.value
    df1[nrow(df1)+1,] <- c(exp.name,b)
  }
}
#----------------------------------------------------------------


############################################
#
# INSTALL AND LOAD NEEDED PACKAGES
#
############################################

toInstallCandidates <- c("graphics", "ggplot2", "h2o")
# check if pkgs are already present
toInstall <- toInstallCandidates[!toInstallCandidates%in%library()$results[,1]] 
if(length(toInstall)!=0)
{install.packages(toInstall, repos = "http://cran.r-project.org")}
# load pkgs
lapply(toInstallCandidates, library, character.only = TRUE)


#glm.data = as.data.frame(df)

str(glm.data)

for (i in 1:(ncol(glm.data)-1)) {
  l1.name = names(glm.data)[i]
  l1.class = class(glm.data[,i])
  print(l1.name)
  if (l1.class %in% c('integer', 'numeric')){
    
    p = ggplot(glm.data, aes(x=glm.data[,names(glm.data) == l1.name], fill=glm.data$response)) +
      geom_density(alpha=.3) +
      ggtitle(paste('Density Plot of', l1.name, 'vs Response')) + 
      xlab(l1.name) +
      ylab(paste(l1.name, ' Density')) +
      guides(fill=guide_legend(title='Response')) +
      theme_minimal()
    
    q = ggplot(glm.data, aes(x=glm.data$response, y=glm.data[,names(glm.data) == l1.name], fill = glm.data$response)) +
      geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=2, size=2) + theme_minimal() +
      ggtitle(paste('Box Plot of', l1.name, 'vs Response')) + 
      xlab('Response') +
      ylab(paste(l1.name)) +
      guides(fill=guide_legend(title='Response')) +
      theme_minimal()
    
    r = wilcox.test(glm.data[,names(glm.data) == l1.name] ~ glm.data$response)
    print(p)
    print(q)
    print(r)
  } else {
    p = mosaicplot(with(glm.data, table(glm.data[,names(glm.data) == l1.name], glm.data$response)), color = c(5,7), main = paste('Effect of ', l1.name, ' on Response'))
    
    q = ggplot(glm.data, aes(x=glm.data$response, y=glm.data[,names(glm.data) == l1.name], fill = glm.data$response)) +
      geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=2, size=2) + theme_minimal() +
      ggtitle(paste('Box Plot of', l1.name, 'vs Response')) + 
      xlab('Response') +
      ylab(paste(l1.name)) +
      guides(fill=guide_legend(title='Response')) +
      theme_minimal()
    
    r = chisq.test(table(glm.data[,names(glm.data) == l1.name], glm.data$response), simulate.p.value = TRUE)
    print(p)
    print(q)
    print(r)
  }
  i = i+1
}

```

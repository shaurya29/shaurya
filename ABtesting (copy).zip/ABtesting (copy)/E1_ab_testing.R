#----------------------A/B Testing----------------------#
setwd("~/ABtesting (copy)")
exp.data = read.csv(file = "exp1.csv", stringsAsFactors = FALSE)
exp.data = data.frame(exp.data)
str(exp.data)
exp.data = subset(exp.data, control_target %in% c('Hidden', 'original'))

exp.data$control_target = as.factor(exp.data$control_target)
exp.data[,1] = NULL
summary(exp.data)
target = exp.data$control_target
exp.data = exp.data[,-3]
df <- data.frame("Names" = character(0),"P_Values" = integer(0),stringsAsFactors = FALSE)

##---------------For_Loop--------------------##

for (i in 1:(ncol(exp.data))){
  exp.name = names(exp.data[i])
  exp.class = class(exp.data[,i])
  print(exp.name)
  if (exp.class %in% c('integer', 'numeric')){
    a = wilcox.test(exp.data[,i] ~ target)$p.value
    df[nrow(df)+1,] <- c(exp.name,a)
  }else {
    b = chisq.test(target,exp.data[,i])$p.value
    df[nrow(df)+1,]<- c(exp.name,b)
  }
}
#----------------------------------------------------------------





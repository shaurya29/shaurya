#Group_A
#----------------------A/B Testing----------------------#
setwd("~/ABtesting (copy)")
exp.data = read.csv(file = "exp2.csv", stringsAsFactors = FALSE)
exp.data = data.frame(exp.data)
str(exp.data)
exp.data = subset(exp.data, control_target %in% c('enable', 'original'))

exp.data$control_target = as.factor(exp.data$control_target)
exp.data[,1] = NULL
summary(exp.data)
#target = exp.data$control_target
#exp.data = exp.data[,-3]
df1 <- data.frame("Names" = character(0),"P_Values" = integer(0),"Mean_of_grpA" = integer(0),"Mean_of_grpB" = integer(0),stringsAsFactors = FALSE)

##---------------For_Loop--------------------##

for (i in 2:(ncol(exp.data))){
  exp.name = names(exp.data[i])
  exp.class = class(exp.data[,i])
  print(exp.name)
  if (exp.class %in% c('integer', 'numeric')){
    a = wilcox.test(exp.data[,i] ~ exp.data$control_target)$p.value
    Mean_A = mean(exp.data[exp.data$control_target == 'enable',i])
    Mean_B = mean(exp.data[exp.data$control_target == 'original',i])
    Mean_A[is.na(Mean_A)] <- 0
    Mean_B[is.na(Mean_B)] <- 0
    df1[nrow(df1)+1,] <- c(exp.name,a,Mean_A,Mean_B)
  }
}


#-------------Calculating % diff between mean--------------------

df1$Mean_of_grpA = as.numeric(df1$Mean_of_grpA)
df1$Mean_of_grpB = as.numeric(df1$Mean_of_grpB)
mean_table <- cbind(df1$Mean_of_grpA,df1$Mean_of_grpB)
colnames(mean_table) <- c("Mean_of_grpA","Mean_of_grpB")
mean_table[is.na(mean_table)] <- 0
mean_table <- as.data.frame(mean_table)
Perc_diff_Means <- abs(mean_table$Mean_of_grpA - mean_table$Mean_of_grpB)*100
mean_table <- cbind(mean_table,Perc_diff_Means)
df1 <- cbind(df1,Perc_diff_Means)

#-----------saving both grpA and grpB in one data_frame--------------------------
write.csv(df1,"df1.csv")

#-------------------------------------------------------------------

